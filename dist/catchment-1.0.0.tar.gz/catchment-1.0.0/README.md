# RiverCatch

![CI](https://github.com/n400peanuts/python-intermediate-rivercatchment/workflows/CI/badge.svg?branch=develop)

This is a try over the readme.